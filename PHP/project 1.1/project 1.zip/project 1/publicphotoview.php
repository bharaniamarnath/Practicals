<?php
session_start();
include('includes/header.php');
include('includes/connect.php');
include('includes/alerts.php');
if(!isset($_SESSION['user'])){
echo $logdenyalert;
}
$suname = $_SESSION['user'];
$result = mysql_query("SELECT * FROM userdetails WHERE Username='$_SESSION[user]'");
while($row = mysql_fetch_array($result))
{
$userid = $row['ID'];
$usrnme = $row['Username'];
$fname = $row['Firstname'];
$lname = $row['Lastname'];
$gend = $row['Gender'];
$mail = $row['Email'];
$dob = $row['Dob'];
$age = floor( (strtotime(date('Y-m-d')) - strtotime($dob)) / 31556926);
}
$imgresult = mysql_query("SELECT * FROM imagedetails WHERE Username='$_SESSION[user]'");
if(mysql_num_rows($imgresult)==0){
echo $dbalert;
}
else{
$row = mysql_fetch_assoc($imgresult);
$imgloc = $row['Image'];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Webstar - Image Upload</title>
<meta name="" content="">
<link rel="stylesheet" type="text/css" href="css/layout.css" />
<link rel="stylesheet" type="text/css" href="css/menu.css" />
<link rel="stylesheet" type="text/css" href="css/submenu.css" />
</head>
<body>
<div id="container">
<div id="leftpane">
<div class="dashboard"><div id="profileimage"><?php echo "<a href='profile.php'><img src='album/thumbs/$userid.jpg' id='profilecrop' /></a>"; ?></div><h2><?php echo $fname . ' ' . $lname; ?></h2><?php echo $usrnme; ?><br /><?php echo $mail; ?></div>
<div id="menubar">
<div id="holder">
<ul>
<li><a href="main.php">Home</a></li>
<li><a href="profile.php">Profile</a></li>
<li><a href="friends.php">Friends</a></li>
<li><a id="onlink" href="photos.php">Photos</a></li>
<li><a href="inbox.php">Messages</a></li>
</ul>		
</div>
</div>
</div>
<div id="rightpane">
<div class="postboard">
<div id="submenubar">
<div id="holder">
<ul>
<li><a href="photos.php">Private Photos</a></li>
<li><a id="onlink" href="publicphotos.php">Public Photos</a></li>
<li><a href="uploadphotos.php">Upload Photos</a></li>
</ul>		
</div>
</div>
<div class="messageboard" style="border:none;">
<?php
if(isset($_GET['photoid'])){
$picvdet = mysql_real_escape_string($_GET['photoid']);
$vpicres = mysql_query("SELECT * FROM publicphotos WHERE ID='$picvdet'");
while($vpicrow = mysql_fetch_array($vpicres)){
$vpicid = $vpicrow['ID'];
$vpicimg = $vpicrow['Photo'];
$vpicname= $vpicrow['Filename'];
$vpicuname = $vpicrow['Username'];
$vpicdesc = $vpicrow['Description'];
$vpicdate = $vpicrow['Date'];

$vote = mysql_query("SELECT * FROM publicvotes WHERE ID='$vpicid'");
$countvote = mysql_num_rows($vote);

echo "<div class='photobox'>";
echo "<table class='photoedit'>";
echo "<form action='publiccomment.php' method='POST'>";
echo "<th><h4>Public Photo: $vpicname</h4></th>";
echo "<tr>";
echo "<td><img class='picscreen' src=$vpicimg /></td>";
echo "</tr>";
echo "<tr>";
echo "<td id='aboutpic'><h4>Uploaded by: $vpicuname<br />$vpicdate<br />$vpicdesc</h4></td>";
echo "</tr>";
echo "<tr>";
echo "<td class='picedit'>Comment Photo: <div class='votes'>Votes: $countvote</div><br /><br /><textarea name='piccomm'></textarea></td>";
echo "</tr>";
echo "<tr>";
echo "<input type='hidden' name='commentpic' value='$vpicimg' />";
echo "<td><input type='submit' name='commpic' id='ppbutton' value='Comment'>";
echo "<input type='button' onClick='history.back()' value='Back' id='ppbutton'></input></td>";
echo "</form></td>";
echo "<td><form action='photovotes.php' method='POST'>";
echo "<input type='hidden' name='votepic' value='$vpicid' />";
echo "<input type='submit' name='vote' value='Vote' id='ppvbutton'></input></td>";
echo "</form>";
echo "</tr>";
echo "</table>";
$dispcomm = mysql_query("SELECT * FROM photocomments WHERE Photo='$vpicimg' ORDER BY Date DESC");
while($dcrow = mysql_fetch_array($dispcomm)){
$dcuname = $dcrow['Username'];
$dccomment = $dcrow['Comment'];
$dcdate = $dcrow['Date'];
$dcpic = mysql_query("SELECT * FROM imagedetails WHERE Username='$dcuname'");
while($dcprow = mysql_fetch_array($dcpic)){
$dcupic = $dcprow['Image'];
echo "<div class='postbox'>";
echo "<div id='postimg'><img id='postimgcrop' src='$dcupic' /></div>";
echo "<div id='posttime'>Posted on: $dcdate</div>";
echo "<h4>";
echo $dcuname;
echo "</h4>";
echo "<font id='postmessage'>".$dccomment."</font>";
echo "<form action='deletecomment.php' method='POST'>";
echo "<input type='hidden' name='commdate' value='$dcdate' />";
echo "<input type='hidden' name='commuser' value='$dcuname' />";
echo "<input type='submit' name='delete' id='postdelete' value='delete'>";
echo "</form>";		
echo "</div>";
}
}
}

}
?>
</div>
</div>
</div>
</div>
<div id="controlmenu">
<input id="signout" type='button' onClick=parent.location='signout.php' value='Sign Out'></input>
<input id="signout" type='button' onClick=parent.location='profile.php' value='Profile'></input>
<input id="signout" type='button' onClick=parent.location='main.php' value='Home'></input>
</div>
<div class="footlink"><a href="terms.php" class="terms">Terms &amp; Conditions</a> . <a href="about.php" class="terms">About Webstar</a> . <a href="feedback.php" class="terms">Feedback</a></div>
<div id="footer">&copy;Copyrights 2013. Webstar Network.</div>
</body>
</html>