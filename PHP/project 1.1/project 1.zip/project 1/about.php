<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Sign Up</title>
<meta name="" content="">
<link rel="stylesheet" type="text/css" href="css/layout.css" />
</head>
<body>
<div class='header'>
<br /><img src="images/header.png"></img>
</div>
<div class="mainboard" style="border-top: 1px solid #00b0dd;">
<h3>About Webstar: </h3>
<div class="termbox">
<center><h2>WEBSTAR SOCIAL NETWORK</h2>
<p>Version 1.0<br />
Developed and designed by <font color='#309cbc'>Bharane Amarnath</font></br >
&copy;Copyrights 2013. Webstar Network.
</p></center>
</div>
<input type="button" value="Back" onClick="history.go(-1)"></input><br />
</div>
</body>
</html>