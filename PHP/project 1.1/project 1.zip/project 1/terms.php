<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Sign Up</title>
<meta name="" content="">
<link rel="stylesheet" type="text/css" href="css/layout.css" />
</head>
<div class='header'>
<br /><img src="images/header.png"></img>
</div>
<div class="mainboard" style="border-top: 1px solid #00b0dd;">
<h3>Terms &amp; Conditions: </h3>
<div class="termbox">
<p>Webstar Network &copy; is a free and simple social network with basic necessary contents that are required for a default social network. Webstar is designed as a communication and sharing source within some small networks and groups in the internet. Since it is a free to join network, and a basic version, the requirements are under the normal expectations by the users.</p><br />
<p>The user can simply register to the webstar by filling in the basic information that are given as a registration form in the index page of the site. The user is requested to provide valid and mostly true information in the registration form, so the user can be identified for any other validation purpose and from piracy.</p><br />
<p>Webstar validates each and every information provided by the user during registration and after the registration session. Once the user is successfully registered, the user can update their profile details. In case not provided, the profile is not going to affect the other process. The profile updating process is just a basic personal details requirement that will be later easy to identify the user by the other users on the network. Since this is a social network, the informations are required from the user for the same purpose.</p><br /> 
<p>Adding friends to the user profile is a very simple process in this netowrk. Every user after the registration is notified in the public page where other users can find them and add them to the friends list if needed. The user would go through the profiles and add a friend, or later the user can either remove the added friend from the profile.</p><br />
<p>Though requirements are under the expectations, privacy is also under expectation. But the user is guided through the network on how to follow privacy, even if there is no automated privacy checks and conditions.</p><br />
<p>The user is allowed to share messages and contetnts on public to get attention and convey socially. The communication setting in public mode is very liberal. The users can interact wit each other in open to everyone. Though privacy is very high at risk in this part, still the user have to understand the risks of sharing the contents in public</p><br />
<p>Apartly, a user can send a private mail to other users using the mail options, thsi message is not public and can be known to only the sender and reciever. the user can eother reply in private or delete the read mails through options.</p><br />
<p>The user can follow the provided terms and conditions by accepting it and register to webstar, a free simple social network and use the site with safe privacy of self and others</p>
</div>
<input type="button" value="Back" onClick="history.go(-1)"></input>
<br />
</div>
<div class="footlink"><a href="terms.php" class="terms">Terms &amp; Conditions</a> . <a href="about.php" class="terms">About Webstar</a> . <a href="feedback.php" class="terms">Feedback</a></div>
<div id="footer">&copy;Copyrights 2013. Webstar Network.</div>
</body>
</html>