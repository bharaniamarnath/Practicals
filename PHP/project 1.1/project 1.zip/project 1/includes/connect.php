<?php
$con = mysql_connect("localhost", "bharane", "21feb1991");
mysql_select_db("webstar", $con);
if(!$con){
	die("Could not connect: " .mysql_error());
}
?>