<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<title>Webstar</title>
<head>
<meta name="" content="">
<link rel="stylesheet" type="text/css" href="css/layout.css" />
</head>
<body oncontextmenu="return false;">
<div class="header">
<div class="searchbar"><form action="search.php" method="POST">
<input type="text" name="searchkey" id="search" value="Enter a username" style="color: #ccc; padding: 5px; margin-top: 5px;" onclick="this.value='';this.style.color='#000';"></input>
<input type="submit" name="search" value="Search" style="padding:6px 10px 6px 10px;" />
</form>
</div>
<img src="images/logo.png"></img>
</div>
</body>
</html>