<?php
session_start();
include('includes/header.php');
include('includes/connect.php');
include('includes/alerts.php');
if(!isset($_SESSION['user'])){
echo $logdenyalert;
}
$suname = $_SESSION['user'];
$result = mysql_query("SELECT * FROM userdetails WHERE Username='$suname'");
while($row = mysql_fetch_array($result))
{
$userid = $row['ID'];
$usrnme = $row['Username'];
$fname = $row['Firstname'];
$lname = $row['Lastname'];
$gend = $row['Gender'];
$mail = $row['Email'];
$dob = $row['Dob'];
$age = floor( (strtotime(date('Y-m-d')) - strtotime($dob)) / 31556926);
}
$proresult = mysql_query("SELECT * FROM personaldetails WHERE Username='$suname'");
while($prow = mysql_fetch_array($proresult))
{
$userid = $prow['ID'];
$occ = $prow['Occupation'];
$cont = $prow['Contact'];
$city = $prow['City'];
$cntry = $prow['Country'];
$schl = $prow['School'];
$wrk = $prow['Work'];
$lang = $prow['Language'];
$abtme = $prow['About'];	
}
$imgresult = mysql_query("SELECT * FROM imagedetails WHERE Username='$suname'");
if(mysql_num_rows($imgresult)==0){
echo $dbalert;
}
else{
$row = mysql_fetch_assoc($imgresult);
$imgloc = $row['Image'];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Webstar</title>
<meta name="" content="">
<link rel="stylesheet" type="text/css" href="css/layout.css" />
<link rel="stylesheet" type="text/css" href="css/menu.css" />
<link rel="stylesheet" type="text/css" href="css/submenu.css" />
</head>
<body>
<div id="container">
<div id="leftpane">
<div class="dashboard"><div id="profileimage"><?php echo "<a href='profile.php'><img src='$imgloc' id='profilecrop' /></a>"; ?></div><h2><?php echo $fname . ' ' . $lname; ?></h2><?php echo $usrnme; ?><br /><?php echo $mail; ?></div>
<div id="menubar">
<div id="holder">
<ul>
<li><a id="onlink" href="main.php">Home</a></li>
<li><a href="profile.php">Profile</a></li>
<li><a href="friends.php">Friends</a></li>
<li><a href="photos.php">Photos</a></li>
<li><a href="inbox.php">Messages</a></li>
<li><a href="groups.php">Groups</a></li>
</ul>		
</div>
</div>
</div>
<div id="rightpane">
<div class="postboard">
<div id="submenubar">
<div id="holder">
<ul>
<li><a id="onlink" href="main.php">My Board</a></li>
<li><a href="publicpost.php">Public Board</a></li>
<li><a href="friendboard.php">Friends Board</a></li>
</ul>		
</div>
</div>
<div class="messageboard"><form action="message.php" method="POST"><p>Post Message:</p><textarea name="msgpost"></textarea><br /><input type="submit" name="post" value='Post' id="postbutton"></input></form><br /></div>
<div id="post">
<?php 
$perpage = 20;
$msgcount = mysql_query("SELECT COUNT(*) FROM messages WHERE Username='$suname'");
$pages = ceil(mysql_result($msgcount, 0) / $perpage);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $perpage;
$msgresult = mysql_query("SELECT * FROM messages WHERE Username='$suname' ORDER BY Time DESC LIMIT $start, $perpage");
while($msgrow = mysql_fetch_array($msgresult))
{
$postimg = $msgrow['Image'];
$posttime = $msgrow['Time'];
$postuname = $msgrow['Username'];
$postm = $msgrow['Message'];
echo "<div class='postbox'>";
echo "<div id='postimg'><img id='postimgcrop' src='$imgloc' /></div>";
echo "<div id='posttime'>Posted on: $posttime</div>";
echo "<h4>";
echo $postuname;
echo "</h4>";
echo "<font id='postmessage'>".$postm."</font>";
echo "<form action='postdelete.php' method='POST'>";
echo "<input type='hidden' name='deletemsg' value='$postm' />";
echo "<input type='submit' name='delete' id='postdelete' value='Delete'>";
echo "</form>";	
echo "</div>";	
}
?>
</div>
<?php
echo "<div id='pagenumbers'>";
if($pages>=1 && $page<=$pages){
for($x = 1; $x <= $pages ; $x++){
echo ($x == $page) ? "<a id='selected' href='?page=$x'>$x</a> " : "<a id='notselected' href='?page=$x'>$x</a> ";	
}
}
echo "</div>";
?>

</div>
</div>
<div id="controlmenu">
<input id="signout" type='button' onClick=parent.location='signout.php' value='Sign Out'></input>
<input id="signout" type='button' onClick=parent.location='profile.php' value='Profile'></input>
<input id="signout" type='button' onClick=parent.location='main.php' value='Home'></input>
</div>
<div class="footlink"><a href="terms.php" class="terms">Terms &amp; Conditions</a> . <a href="about.php" class="terms">About Webstar</a> . <a href="feedback.php" class="terms">Feedback</a></div>
<div id="footer">&copy;Copyrights 2013. Webstar Network.</div>
</div>
</body>
</html>