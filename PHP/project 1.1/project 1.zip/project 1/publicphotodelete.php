<?php
	include('includes/header.php');
	include('includes/connect.php');
	include('includes/alerts.php');
	if(isset($_POST['picdelete'])){
		$delpic = mysql_real_escape_string($_POST['deletepic']);
		$delmsg = mysql_query("DELETE FROM publicphotos WHERE Photo='$delpic'");
		$image = rawurldecode(basename($delpic));
		@unlink("./publicphotos/" . $image);
		@unlink("./publicphotos/thumbs/" . $image);
		if($delmsg){
			header("Location: mypublicphotos.php");
		}
		else{
			echo $delpicalert;
			
		}
		}
?>