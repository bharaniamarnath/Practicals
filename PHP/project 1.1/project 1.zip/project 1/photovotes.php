<?php
session_start();
include('includes/header.php');
include('includes/connect.php');
include('includes/alerts.php');
if(!isset($_SESSION['user'])){
	echo $logdenyalert;
}
	$suname = $_SESSION['user'];
	if(isset($_POST['vote'])){
		$picid = mysql_real_escape_string($_POST['votepic']);
		$chkvote = mysql_query("SELECT * FROM publicvotes WHERE ID='$picid'");
		while($chkuser = mysql_fetch_array($chkvote)){
		$usrname = $chkuser['Username'];
		if($usrname == $suname){
			echo $votealert;
			exit();
		}
		}
		$addvote = mysql_query("INSERT INTO publicvotes (ID,Username) VALUES ('$picid','$suname')");
		if($addvote){
			header("Location: publicphotoview.php?photoid=$picid");
		}		
		else{
			echo $votefalert;
		}
	}
?>