<?php
session_start();
include('includes/header.php');
include('includes/connect.php');
include('includes/alerts.php');
if(!isset($_SESSION['user'])){
echo $logdenyalert;
}
$suname = $_SESSION['user'];	
?>
<?php
if(isset($_POST['commpic'])){
$cpuid = rand(000000,999999);
$cpic = mysql_real_escape_string($_POST['commentpic']);
$pcomm = mysql_real_escape_string($_POST['piccomm']);
$cpicdet = mysql_query("SELECT * FROM userdetails WHERE Username='$suname'");
$cpquery = mysql_query("INSERT INTO photocomments (ID, Username, Photo, Comment) VALUES ('$cpuid', '$suname', '$cpic', '$pcomm')");
if($cpquery){
	echo $commentalert;
}
else
{
	echo $commfailalert;
}
	 
}
?>