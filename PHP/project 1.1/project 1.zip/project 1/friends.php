<?php
session_start();
include('includes/header.php');
include('includes/connect.php');
include('includes/alerts.php');
if(!isset($_SESSION['user'])){
echo $logdenyalert;
}
$suname = $_SESSION['user'];
$result = mysql_query("SELECT * FROM userdetails WHERE Username='$_SESSION[user]'");
while($row = mysql_fetch_array($result))
{
$userid = $row['ID'];
$usrnme = $row['Username'];
$fname = $row['Firstname'];
$lname = $row['Lastname'];
$gend = $row['Gender'];
$mail = $row['Email'];
$dob = $row['Dob'];
$age = floor( (strtotime(date('Y-m-d')) - strtotime($dob)) / 31556926);
}
$imgresult = mysql_query("SELECT * FROM imagedetails WHERE Username='$_SESSION[user]'");
if(mysql_num_rows($imgresult)==0){
echo $dbalert;
}
else{
$row = mysql_fetch_assoc($imgresult);
$imgloc = $row['Image'];
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Webstar - Friends</title>
<meta name="" content="">
<link rel="stylesheet" type="text/css" href="css/layout.css" />
<link rel="stylesheet" type="text/css" href="css/menu.css" />
<link rel="stylesheet" type="text/css" href="css/submenu.css" />
</head>
<body>
<div id="container">
<div id="leftpane">
<div class="dashboard"><div id="profileimage"><?php echo "<a href='imageupload.php'><img src='$imgloc' id='profilecrop' /></a>"; ?></div><h2><?php echo $fname . ' ' . $lname; ?></h2><?php echo $usrnme; ?><br /><?php echo $mail; ?></div>
<div id="menubar">
<div id="holder">
<ul>
<li><a href="main.php">Home</a></li>
<li><a href="profile.php">Profile</a></li>
<li><a id="onlink" href="friends.php">Friends</a></li>
<li><a href="photos.php">Photos</a></li>
<li><a href="inbox.php">Messages</a></li>
</ul>		
</div>
</div>
</div>
<div id="rightpane">
<div class="postboard">
<div id="submenubar">
<div id="holder">
<ul>
<li><a id="onlink" href="friends.php">Friends</a></li>
<li><a href="people.php">People</a></li>
<li><a href="friendrequest.php">Friend Requests</a></li>
</ul>		
</div>
</div>
<div class="messageboard" style="border:none;">
<?php 
$perpage = 20;
$msgcount = mysql_query("SELECT COUNT(*) FROM friends WHERE Username='$suname'");
$pages = ceil(mysql_result($msgcount, 0) / $perpage);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $perpage;
$listres = mysql_query("SELECT * FROM friends WHERE Username='$suname' ORDER BY Username LIMIT $start, $perpage");
if(mysql_num_rows($listres)==0){
echo $nofrndsalert;
}
while($frow = mysql_fetch_array($listres)){
$fusrnme = $frow['Friend'];
$_SESSION['fprofile']=$fusrnme;
$frnddet = mysql_query("SELECT * FROM userdetails WHERE Username='$fusrnme'");
while($fdrow = mysql_fetch_array($frnddet)){
$ffname = $fdrow['Firstname'];
$flname = $fdrow['Lastname'];
$fgend = $fdrow['Gender'];
$fimgresult = mysql_query("SELECT * FROM imagedetails WHERE Username='$fusrnme'");
while($imgrow = mysql_fetch_array($fimgresult)){
$postimg = $imgrow['Image'];
echo "<div class='friendbox'>";
echo "<img align='left' id='thumbimgcrop' src='$postimg' />";
echo "<p>$ffname $flname<br /><font id='postmessage'>$fusrnme</font></p>";
echo "<form action='viewfriend.php' method='POST'>";
echo "<input type='hidden' name='viewpro' value='$fusrnme' />";
echo "<input type='submit' name='viewprofile' value='View Profile'>";
echo "</form>";
echo "<form action='deletefriend.php' method='POST'>";
echo "<input type='hidden' name='delfrnd' value='$fusrnme' />";
echo "<input type='submit' name='deletefriend' value='Remove Friend'>";
echo "</form>";
echo "</div>";
}
}
}
?>
</div>
<?php
echo "<div id='pagenumbers'>";
if($pages>=1 && $page<=$pages){
for($x = 1; $x <= $pages ; $x++){
echo ($x == $page) ? "<a id='selected' href='?page=$x'>$x</a> " : "<a id='notselected' href='?page=$x'>$x</a> ";	
}
}
echo "</div>";
?>
</div>
</div>
</div>
</div>
<div id="controlmenu">
<input id="signout" type='button' onClick=parent.location='signout.php' value='Sign Out'></input>
<input id="signout" type='button' onClick=parent.location='profile.php' value='Profile'></input>
<input id="signout" type='button' onClick=parent.location='main.php' value='Home'></input>
</div>
<div class="footlink"><a href="terms.php" class="terms">Terms &amp; Conditions</a> . <a href="about.php" class="terms">About Webstar</a> . <a href="feedback.php" class="terms">Feedback</a></div>
<div id="footer">&copy;Copyrights 2013. Webstar Network.</div>
</body>
</html>