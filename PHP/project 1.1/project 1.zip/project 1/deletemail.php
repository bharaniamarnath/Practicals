<?php
include('includes/header.php');
include('includes/connect.php');
include('includes/alerts.php');
if(isset($_POST['delete'])){
$delmail = mysql_real_escape_string($_POST['delmail']);
$deletemail = mysql_query("DELETE FROM maildetails WHERE ID='$delmail'");
if($deletemail){
echo $maildelalert;
exit();
}
else{
echo $maildelfalert;
exit();
}
}
if(isset($_POST['deleteall'])){
$delall = mysql_real_escape_string($_POST['usermail']);
$deleteallmail = mysql_query("DELETE FROM maildetails WHERE Reciever='$delall'");
if($deleteallmail){
echo $maildelalert;
exit();
}
else{
echo $maildelfalert;
exit();
}
}
?>